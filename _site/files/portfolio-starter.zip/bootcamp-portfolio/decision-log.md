# Decision log
Question:
Method and provenance:
Evidence:
Interpretation and uncertainty:
Next decision:
